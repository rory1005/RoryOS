#!/bin/bash

###############################################################################
# 项目名称：RoryOS
#
# 文件名称：
#     customize.sh
#
# 文件作用：
#     RoryOS 自定义总入口脚本，负责按顺序调用所有功能模块。
#
# 当前功能：
#     ① 调用系统基础设置脚本
#
# 作者：
#     Rory
#
# 技术支持：
#     福贵（ChatGPT）
#
# 创建日期：
#     2026-07-01
#
# 最后修改：
#     2026-07-01
###############################################################################

set -e

OPENWRT_DIR="${1:-openwrt}"

echo "======================================="
echo "        RoryOS 自定义开始"
echo "======================================="

if [ ! -d "$OPENWRT_DIR" ]; then
  echo "错误：找不到 OpenWrt 目录：$OPENWRT_DIR"
  exit 1
fi

chmod +x scripts/*.sh

bash scripts/01-system.sh "$OPENWRT_DIR"
bash scripts/02-theme.sh "$OPENWRT_DIR"
bash scripts/04-wireless.sh "$OPENWRT_DIR"
bash scripts/devices/ax3000t.sh "$OPENWRT_DIR"
bash scripts/06-network.sh "$OPENWRT_DIR"
bash scripts/07-services.sh "$OPENWRT_DIR"
bash scripts/08-release.sh "$OPENWRT_DIR"

echo "======================================="
echo "        RoryOS 自定义完成"
echo "======================================="
